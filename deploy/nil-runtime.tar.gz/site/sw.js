
'use strict';
const CACHE = 'nil-60c509b8d8ee1874';
const BASE = self.registration.scope;
const ASSETS = ["assets/index-BqqGYDsF.js","assets/index-Diz5R6P2.css","assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2","assets/vazirmatn-latin-ext-wght-normal-tDTa1Fj6.woff2","assets/vazirmatn-latin-wght-normal-BFexNX-K.woff2","branding/creator-logo-charcoal.png","branding/creator-logo.png","data/configs.json","data/history.json","data/status.json","icons/apple-touch-icon.png","icons/favicon-32.png","icons/icon-192.png","icons/icon-512.png","icons/maskable-512.png","index.html","licenses/Vazirmatn-OFL.txt","manifest.webmanifest","theme-init.js"].map(path => new URL(path, BASE).href);
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const shellURL = new URL('index.html', BASE).href;
    await cache.addAll(ASSETS.filter(url => url !== shellURL));
    // Some static hosts redirect index.html to /. Store a fresh 200 response:
    // WebKit refuses a redirected cached response for later app navigations.
    const shell = await fetch(shellURL, { cache: 'reload' });
    if (!shell.ok || new URL(shell.url).origin !== self.location.origin || !shell.url.startsWith(BASE)) throw new Error('App shell unavailable');
    const headers = new Headers(shell.headers);
    headers.delete('Content-Encoding'); headers.delete('Content-Length'); headers.delete('Transfer-Encoding');
    await cache.put(shellURL, new Response(await shell.arrayBuffer(), { status: 200, headers }));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('nil-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !request.url.startsWith(BASE)) return;
  if (url.pathname.startsWith(new URL('data/', BASE).pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        let response;
        try { response = await fetch(request, { cache: 'no-store', signal: controller.signal }); }
        finally { clearTimeout(timer); }
        if (!response.ok) throw new Error('Data unavailable');
        await cache.put(request, response.clone());
        return response;
      } catch {
        const cached = await cache.match(request);
        if (!cached) return new Response('Offline and no cached data', { status: 503 });
        const headers = new Headers(cached.headers); headers.set('X-Nil-Cache', 'offline');
        return new Response(await cached.arrayBuffer(), { status: 200, headers });
      }
    })());
  } else {
    event.respondWith(caches.open(CACHE).then(async cache => {
      // Navigation is the cached app shell. Do not require a failed network
      // navigation before returning it (important for offline WebKit).
      if (request.mode === 'navigate') {
        const shell = await cache.match(new URL('index.html', BASE).href);
        if (shell) return shell;
      }
      const cached = await cache.match(request); if (cached) return cached;
      try { return await fetch(request); }
      catch (error) { if (request.mode === 'navigate') return await cache.match(new URL('index.html', BASE).href) || Response.error(); throw error; }
    }));
  }
});
